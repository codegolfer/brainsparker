"""
Plato bot implementation.
"""
import os
import random

import pyCiscoSpark

# Sets config values from the config file
ACCESS_TOKEN_SPARK = "Bearer " + os.environ['access_token_spark']

FILEPATH = 'sparks.txt'
POTENTIAL_SPARKS = []
with open(FILEPATH) as fp:
    LINE = fp.readline()
    while LINE:
        LINE = fp.readline()
        POTENTIAL_SPARKS.append(LINE.strip())


def post_sparks(event, context):
    """
    HELLO
    """
    spark = random.choice(POTENTIAL_SPARKS)
    room_dict = pyCiscoSpark.get_rooms(ACCESS_TOKEN_SPARK)

    for room in room_dict['items']:
        print "Posting to " + room['title'] + " --- " + spark
        pyCiscoSpark.post_message_rich(ACCESS_TOKEN_SPARK, room['id'], spark)
